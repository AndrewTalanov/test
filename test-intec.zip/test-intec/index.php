<?php

require_once './database.php';
require_once './fields.php';

$database = new Database();
$db = $database->getConnection();

$field = new Fields($db);
$result = $field->verify();

?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test</title>
</head>
<body>
    <div class="wrapper">
        <div class="container">

            <p id="user-id"></p>
            <form action="index.php" method="post" enctype="multipart/form-data">

                <input type="file" name="file" id="file">

                <button type="submit" name="import">Отправить файл</button>
            </form>
            <p> <?php echo $result ?> </p>
            <form action="index.php" method="post">
                <button type="submit" name="export">Скачать бд</button>
            </form>
        </div>    
    </div>

</body>
</html>

<script>
    // ТУТ МОЖНО МЕНЯТЬ USER_ID 
    document.cookie = "user_id=1";

    let userId = getCookie('user_id');

    document.getElementById('user-id').innerHTML = `ID пользователя: ${userId}`;

    function getCookie(name) {

        let matches = document.cookie.match(new RegExp(
            "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
        ));

        return matches ? decodeURIComponent(matches[1]) : undefined;
    }
</script>

<style>
    @import url('https://fonts.googleapis.com/css2?family=Montserrat&display=swap');

    .html, body, p {
        margin: 0;
    }
    .wrapper {
        width: 100%;
        height: 100vh;
        background-color: #f2f2f2;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .container {
        background-color: #fff;
        border-radius: 30px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        gap: 30px;
        padding: 50px;
        box-sizing: border-box;
    }
    p {
        text-align: center;
    }
    p, button, input {
        font-family: 'Montserrat', sans-serif;
        font-size: 16px;
    }
    button {
        padding: 10px 30px;
        background-color: white;
        border-radius: 15px;
        cursor: pointer;
        transition: .4s;
    }
    button:active {
        transform: scale(.9);
    }
    button:hover {
        color: white;
        background-color: black;
    }
</style>