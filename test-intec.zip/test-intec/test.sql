-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Дек 14 2022 г., 12:26
-- Версия сервера: 5.7.33
-- Версия PHP: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `test`
--

-- --------------------------------------------------------

--
-- Структура таблицы `product`
--

CREATE TABLE `product` (
  `id` int(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `name_trans` varchar(30) NOT NULL,
  `price` int(10) NOT NULL,
  `small_text` varchar(30) NOT NULL,
  `big_text` varchar(100) NOT NULL,
  `user_id` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `product`
--

INSERT INTO `product` (`id`, `name`, `name_trans`, `price`, `small_text`, `big_text`, `user_id`) VALUES
(1, 'телефон', 'phone', 100, 'Маленький текст до 30 символов', 'Очень сильно большой текст 30! Далее уже текст за пределами 30 символов.', 1),
(2, 'машина', 'car', 150, 'Маленький текст до 30 символов', 'Очень сильно большой текст 30! Далее уже текст за пределами 30 символов.', 1),
(3, 'посуда', 'tableware', 50, 'Маленький текст до 30 символов', 'Очень сильно большой текст 30! Далее уже текст за пределами 30 символов.', 2),
(4, 'ручка', 'pen', 5, 'Маленький текст до 30 символов', 'Очень сильно большой текст 30! Далее уже текст за пределами 30 символов.', 2),
(2, 'цветок', 'flower', 30, 'Маленький текст до 30 символов', 'Очень сильно большой текст 30! Далее уже текст за пределами 30 символов.', 3),
(4, 'шорты', 'shorts', 50, 'Маленький текст до 30 символов', 'Очень сильно большой текст 30! Далее уже текст за пределами 30 символов.', 3),
(5, 'футболка', 't-shirt', 25, 'Маленький текст до 30 символов', 'Очень сильно большой текст 30! Далее уже текст за пределами 30 символов.', 4),
(6, 'кружка', 'cup', 100, 'Маленький текст до 30 символов', 'Очень сильно большой текст 30! Далее уже текст за пределами 30 символов.', 4),
(1, 'шапка', 'hat', 10, 'Маленький текст до 30 символов', 'Очень сильно большой текст 30! Далее уже текст за пределами 30 символов.', 5);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
