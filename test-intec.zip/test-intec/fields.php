<?php

require_once "./CSV.php";

class Fields
{
    private $db;

    public function __construct($db)
    {
        $this->db = $db;
    }

    public function verify()
    {
        $result = null;

        if (!empty($_POST)) {

            if (array_key_exists('import', $_POST)) {

                $info = new SplFileInfo($_FILES['file']['name']);
                $info = $info->getExtension();

                if ('csv' == $info) {

                    $file = $_FILES['file']['tmp_name'];

                    $csv = new CSV($this->db, $file);
                    $result = $csv->import();

                } else {
                    $result = "Это не csv файл";
                }

            } elseif (array_key_exists('export', $_POST)) {
                $csv = new CSV($this->db);
                $csv->export();
            } else {
                $result = '?';
            }
        } else {
            $result = 'Выберите CSV файл';
        }

        return $result;
    }
}