<?php

class CSV
{
    private $db;
    private $file;

    public function __construct($db, $file = null)
    {
        $this->db = $db;
        $this->file = $file;
    }

    public function import()
    {
        $USER_ID_COOKIE = $_COOKIE['user_id'];
        $count_update = 0;
        $count_new = 0;

        if (($handle = fopen($this->file, "r")) !== FALSE) {

            while (($data = fgetcsv($handle, 10000, ",")) !== FALSE) {
                $id = $data[0];
                $name = $data[1];
                $name_trans = $data[2];
                $price = $data[3];
                $small_text = $data[4];
                $big_text = $data[5];
                $user_id = $data[6];

                if (strlen($small_text) <= 0) {
                    $small_text = mb_strimwidth($big_text, 0, 30);
                } else {
                    $small_text = mb_strimwidth($small_text, 0, 30);
                }
                $small_text = strip_tags($small_text);

                $result_user_id = -1;
                if ($user_id === $USER_ID_COOKIE) {
                    $result_user_id = $USER_ID_COOKIE;
                }

                $has_id = $this->db->prepare("SELECT * FROM `product` WHERE `user_id` = '$result_user_id' AND `id` = '$id'");
                $has_id->execute();
                $has_id = $has_id->fetch(PDO::FETCH_ASSOC);

                if ($has_id !== false) {

                    $count_update ++;

                    $update = $this->db->prepare("UPDATE `product` SET (name, name_trans, price, small_text, big_text) VALUES (:name, :name_trans, :price, :small_text, :big_text) WHERE user_id='$USER_ID_COOKIE' AND id = :id LIMIT 1");

                    $update->bindParam(':id', $id);
                    $update->bindParam(':name', $name);
                    $update->bindParam(':name_trans', $name_trans);
                    $update->bindParam(':price', $price);
                    $update->bindParam(':small_text', $small_text);
                    $update->bindParam(':big_text', $big_text);

                    $update->execute();

                } elseif ( $USER_ID_COOKIE === $user_id ) {

                    $count_new ++;

                    $new = $this->db->prepare("INSERT INTO `product` (`id`, `name`, `name_trans`, `price`, `small_text`, `big_text`, `user_id`) VALUES( :id, :name, :name_trans, :price, :small_text, :big_text, :user_id)");

                    $new->bindParam(':id', $id);
                    $new->bindParam(':name', $name);
                    $new->bindParam(':name_trans', $name_trans);
                    $new->bindParam(':price', $price);
                    $new->bindParam(':small_text', $small_text);
                    $new->bindParam(':big_text', $big_text);
                    $new->bindParam(':user_id', $USER_ID_COOKIE);

                    $new->execute();

                }
            }
            fclose($handle);
        }

        return "Новых элементов: " . $count_new . " Обновленных элементов " . $count_update;

    }

    public function export()
    {
        $USER_ID_COOKIE = $_COOKIE['user_id'];
        $file = 'bd.csv';

        $req = $this->db->query("SELECT * FROM `product` WHERE user_id='$USER_ID_COOKIE'");
        $data = [];

        while ($row = $req->fetch(PDO::FETCH_ASSOC)) {
            $data[] = $row;
        }

        $handle = fopen($file, "w+");

        foreach ($data as $el) {
            fputcsv($handle, $el);
        }

        fclose($handle);

        if (file_exists($file)) {
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="'.basename($file).'"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($file));
            readfile($file);
            exit;
        }
    }

}